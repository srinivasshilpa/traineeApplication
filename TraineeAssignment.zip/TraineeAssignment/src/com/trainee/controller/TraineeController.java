package com.trainee.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.trainee.bean.TraineeBean;
import com.trainee.exception.TraineeException;
import com.trainee.service.ITraineeService;
import com.trainee.service.TraineeSerivceImpl;

@Controller
public class TraineeController {

	@Autowired
	private ITraineeService traineeService;
	
	@RequestMapping("/showHome")
	public String showHomePage()
	{
		return("index");
	}
	
	@RequestMapping("/addTraineeForm")
	public String traineeForm()
	{
		return("addTra");
	}
	
	@RequestMapping(value="addTrainee", method=RequestMethod.POST)
	public ModelAndView addTrain(@ModelAttribute("train") TraineeBean bean,
			BindingResult result)
	{
		ModelAndView mv = new ModelAndView();
		
		if(result.hasErrors())
		{
			mv.setViewName("error");
			mv.addObject("message", "Binding Failed");
		}
		else
		{
			try {
				int id = traineeService.addTrainee(bean);
				mv.setViewName("success");
				mv.addObject("id", id);
				mv.addObject("train", bean);
			} catch (TraineeException e) {
				mv.setViewName("error");
				mv.addObject("message", e.getMessage());
			}
		}
		
		return mv;
	}
	
	@RequestMapping("searchTrainee")
	public ModelAndView search(@ModelAttribute("train") TraineeBean bean,@RequestParam("id") int traineeId)
	{
		ModelAndView mv=new ModelAndView();
		try {
			
			mv.setViewName("find");
			bean = traineeService.search(traineeId);
			mv.addObject("train" ,bean);
			mv.setViewName("delete");
			
		} catch (TraineeException e) {
			mv.setViewName("error");
			mv.addObject("message", e.getMessage());
		}
		
		return mv;
		
	}
		
	
		
	
}
