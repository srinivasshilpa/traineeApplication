package com.trainee.exception;

public class TraineeException extends Exception {
  
	/**
	 * 
	 */
	private static final long serialVersionUID = -827882634578160140L;

	public TraineeException (String message) {
		super(message);
	}
	
}
