package com.trainee.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.trainee.bean.TraineeBean;
import com.trainee.exception.TraineeException;
import com.trainee.service.ITraineeService;

@Controller
public class TraineeController {
	
	@Autowired
    private ITraineeService traineeService;
		
	@RequestMapping("showHomePage")
	public String  showHomePage()
	{
		return("index");
	}
	
	@RequestMapping("add")
	public String  traineeForm()
	{
		return("addtrainee");
	} 
		
	
	@RequestMapping(value="addTrainee", method=RequestMethod.POST)
	public ModelAndView addTrainee(@ModelAttribute("tra") TraineeBean bean,BindingResult result)
	{
		ModelAndView mv = new ModelAndView();
		if(result.hasErrors())
		{
			mv.setViewName("error");
			mv.addObject("message","Binding Failed");
		}else{
			try {
				int id=traineeService.addTrainee(bean);
				mv.setViewName("success");
				mv.addObject("id",id);
				mv.addObject("tra",bean);
			} catch (TraineeException e) {
				mv.setViewName("error");
				mv.addObject("message",e.getMessage());
			}
		}
		return mv;
				
	}
}
