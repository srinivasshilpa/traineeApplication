package com.trainee.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.trainee.bean.TraineeBean;
import com.trainee.dao.ITraineeDAO;
import com.trainee.exception.TraineeException;

@Service
public class TraineeServiceImpl implements ITraineeService {
    @Autowired  
	private ITraineeDAO traineeDao;
		
	
	@Override
	public int addTrainee(TraineeBean bean) throws TraineeException {
		
		return traineeDao.addTrainee(bean);
	}

}
