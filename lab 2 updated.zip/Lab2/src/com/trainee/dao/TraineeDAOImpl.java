package com.trainee.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.trainee.bean.TraineeBean;
import com.trainee.exception.TraineeException;
@Repository
@Transactional
public class TraineeDAOImpl implements ITraineeDAO {
	
	@PersistenceContext
	private EntityManager entityManager;
	@Override
	public int addTrainee(TraineeBean bean) throws TraineeException {
		int id=0;
		try {
			entityManager.persist(bean);
			entityManager.flush();
			id=bean.getTraineeId();
		} catch (Exception e) {
			System.out.println("Counld not add Trainee Details"+e.getMessage());
		}
		return id;
		
	}

}
