package com.trainee.dao;

import com.trainee.bean.TraineeBean;
import com.trainee.exception.TraineeException;

public interface ITraineeDAO {

	public int addTrainee(TraineeBean bean) throws TraineeException;
	
	/*public TraineeBean deleteTrainee(int traineeId) throws TraineeException;

	public boolean updateTrainee(TraineeBean bean) throws TraineeException;
		
	public TraineeBean getTraineeDetails(int traineeId) throws TraineeException;
	
	public List<TraineeBean> getAllTraineeDetails()  throws TraineeException;*/

}


